from django.shortcuts import render, get_object_or_404, redirect
from .models import Product, CartItem, Order, OrderItem, Category
from .forms import RegisterForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Count

def index(request):
    top_products = Product.objects.all()[:8]
    return render(request, 'store/index.html', {'top_products': top_products})

def product_list(request):
    products = Product.objects.all()
    categories = Category.objects.annotate(num_products=Count('product')).all()
    return render(request, 'store/product_list.html', {'products': products, 'categories': categories})

def product_detail(request, pk):
    product = get_object_or_404(Product, pk=pk)
    # Simple recommendation: other products in same category
    if product.category:
        recs = Product.objects.filter(category=product.category).exclude(pk=product.pk)[:4]
    else:
        recs = Product.objects.exclude(pk=product.pk)[:4]
    return render(request, 'store/product_detail.html', {'product': product, 'recs': recs})

@login_required
def add_to_cart(request, pk):
    product = get_object_or_404(Product, pk=pk)
    cart_item, created = CartItem.objects.get_or_create(user=request.user, product=product)
    if not created:
        cart_item.quantity += 1
    cart_item.save()
    messages.success(request, f'Added {product.name} to cart.')
    return redirect('store:view_cart')

@login_required
def view_cart(request):
    items = CartItem.objects.filter(user=request.user)
    total = sum(item.line_total() for item in items)
    return render(request, 'store/cart.html', {'items': items, 'total': total})

@login_required
def checkout(request):
    items = CartItem.objects.filter(user=request.user)
    if not items.exists():
        messages.error(request, 'Your cart is empty.')
        return redirect('store:product_list')
    order = Order.objects.create(user=request.user)
    for item in items:
        OrderItem.objects.create(order=order, product=item.product, quantity=item.quantity)
        # adjust stock safely
        if item.product.stock >= item.quantity:
            item.product.stock -= item.quantity
            item.product.save()
    items.delete()
    messages.success(request, 'Order placed successfully!')
    return redirect('store:index')

def register_view(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('store:index')
    else:
        form = RegisterForm()
    return render(request, 'store/register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('store:index')
        else:
            messages.error(request, 'Invalid credentials')
    return render(request, 'store/login.html')

@login_required
def logout_view(request):
    logout(request)
    return redirect('store:index')
