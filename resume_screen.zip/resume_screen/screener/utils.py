import os
import io
from pdfminer.high_level import extract_text as pdf_extract_text
import docx

# a modest built-in skill list for extraction - extend as needed
COMMON_SKILLS = [
    "python","django","flask","rest","sql","postgresql","mysql","nosql","mongodb",
    "javascript","react","vue","html","css","git","aws","docker","kubernetes",
    "linux","java","c++","c#","machine learning","ml","tensorflow","pytorch",
    "nlp","data analysis","pandas","numpy","scikit-learn","excel","rest api"
]

def extract_text_from_file(file_path, filename=None):
    """
    Try to extract text from pdf, docx or txt.
    Returns plain text.
    """
    filename = filename or file_path
    ext = os.path.splitext(filename)[1].lower()
    if ext == '.pdf':
        try:
            text = pdf_extract_text(file_path)
            return text or ""
        except Exception:
            return ""
    elif ext in ('.docx',):
        try:
            doc = docx.Document(file_path)
            fullText = []
            for para in doc.paragraphs:
                fullText.append(para.text)
            return "\n".join(fullText)
        except Exception:
            return ""
    else:
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read()
        except Exception:
            return ""

def extract_skills_from_text(text, skill_set=None):
    """
    Simple skill-matching: look for known skill tokens in lowercased text.
    Returns a sorted unique list.
    """
    skill_set = skill_set or COMMON_SKILLS
    txt = text.lower()
    found = set()
    for skill in skill_set:
        key = skill.lower()
        # check whole word or phrase presence
        if key in txt:
            found.add(skill)
    return sorted(found)

def summarize_experience(text, max_chars=400):
    """
    Heuristic: look for 'experience' sections or return first chunk.
    """
    lower = text.lower()
    idx = lower.find("experience")
    if idx != -1:
        snippet = text[idx: idx + max_chars]
        return snippet.replace("\n", " ").strip()
    # fallback: first paragraph
    paras = [p.strip() for p in text.split("\n\n") if p.strip()]
    return (paras[0][:max_chars] + "...") if paras else ""

def summarize_education(text, max_chars=300):
    lower = text.lower()
    idx = lower.find("education")
    if idx != -1:
        snippet = text[idx: idx + max_chars]
        return snippet.replace("\n", " ").strip()
    # fallback try to find 'bachelor' or 'b.sc' etc
    keywords = ['bachelor', 'master', 'b.sc', 'm.sc', 'b.tech', 'm.tech', 'degree']
    for kw in keywords:
        idx = lower.find(kw)
        if idx != -1:
            snippet = text[idx: idx + max_chars]
            return snippet.replace("\n", " ").strip()
    return ""
