from django.urls import path
from . import views

app_name = "screener"

urlpatterns = [
    path('', views.index, name='index'),
    path('jobs/', views.job_list, name='job_list'),
    path('jobs/create/', views.job_create, name='job_create'),
    path('resume/upload/', views.upload_resume, name='upload_resume'),
    path('resume/<int:pk>/', views.resume_detail, name='resume_detail'),
]
