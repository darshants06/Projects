from django.db import models
from django.contrib.auth.models import User

class Job(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    required_skills = models.TextField(help_text="Comma separated skills, e.g. Python,Django,REST")
    created_at = models.DateTimeField(auto_now_add=True)

    def skills_list(self):
        return [s.strip().lower() for s in self.required_skills.split(",") if s.strip()]

    def __str__(self):
        return f"{self.title}"

class Resume(models.Model):
    name = models.CharField(max_length=200)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    file = models.FileField(upload_to='resumes/')
    text = models.TextField(blank=True)  # extracted text
    skills = models.TextField(blank=True)  # comma-separated extracted skills
    experience_summary = models.TextField(blank=True)
    education_summary = models.TextField(blank=True)

    def skills_list(self):
        return [s.strip().lower() for s in self.skills.split(",") if s.strip()]

    def __str__(self):
        return f"{self.name} - {self.uploaded_at.date()}"
