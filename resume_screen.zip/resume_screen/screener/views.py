import os
from django.shortcuts import render, redirect, get_object_or_404
from django.conf import settings
from django.contrib import messages
from .forms import ResumeUploadForm, JobForm
from .models import Resume, Job
from .utils import extract_text_from_file, extract_skills_from_text, summarize_experience, summarize_education

def index(request):
    jobs = Job.objects.order_by('-created_at')[:5]
    resumes = Resume.objects.order_by('-uploaded_at')[:5]
    return render(request, 'screener/index.html', {'jobs': jobs, 'resumes': resumes})

def job_list(request):
    jobs = Job.objects.order_by('-created_at')
    return render(request, 'screener/job_list.html', {'jobs': jobs})

def job_create(request):
    if request.method == 'POST':
        form = JobForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Job created.")
            return redirect('screener:job_list')
    else:
        form = JobForm()
    return render(request, 'screener/job_create.html', {'form': form})

def upload_resume(request):
    if request.method == 'POST':
        form = ResumeUploadForm(request.POST, request.FILES)
        if form.is_valid():
            resume = form.save(commit=False)
            resume_file = request.FILES['file']
            resume.save()
            # extract text
            file_path = os.path.join(settings.MEDIA_ROOT, resume.file.name)
            text = extract_text_from_file(file_path, filename=resume_file.name)
            resume.text = text
            # extract skills
            skills = extract_skills_from_text(text)
            resume.skills = ",".join(skills)
            resume.experience_summary = summarize_experience(text)
            resume.education_summary = summarize_education(text)
            resume.save()
            messages.success(request, "Resume uploaded and parsed.")
            return redirect('screener:resume_detail', pk=resume.pk)
    else:
        form = ResumeUploadForm()
    return render(request, 'screener/upload_resume.html', {'form': form})

def resume_detail(request, pk):
    resume = get_object_or_404(Resume, pk=pk)
    jobs = Job.objects.all()
    scores = []
    for job in jobs:
        required = set([s.lower() for s in job.skills_list()])
        candidate = set(resume.skills_list())
        if not required:
            score = 0
        else:
            matched = required.intersection(candidate)
            score = int(len(matched) / len(required) * 100)
        scores.append({'job': job, 'score': score, 'matched': list(matched) if required else []})
    return render(request, 'screener/resume_detail.html', {'resume': resume, 'scores': scores})
