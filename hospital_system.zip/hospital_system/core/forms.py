from django import forms
from .models import Patient, Appointment, MedicalRecord, Prescription, Doctor
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm

class UserLoginForm(forms.Form):
    username = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control'}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control'}))

class UserRegisterForm(UserCreationForm):
    email = forms.EmailField(required=True, widget=forms.EmailInput(attrs={'class':'form-control'}))

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['username'].widget.attrs.update({'class':'form-control'})
        self.fields['password1'].widget.attrs.update({'class':'form-control'})
        self.fields['password2'].widget.attrs.update({'class':'form-control'})
        self.fields['email'].widget.attrs.update({'class':'form-control'})

class PatientForm(forms.ModelForm):
    class Meta:
        model = Patient
        fields = ['first_name','last_name','dob','gender','phone','email','address','emergency_contact','photo']

class DoctorForm(forms.ModelForm):
    class Meta:
        model = Doctor
        fields = ['user','department','phone','photo','specialization']

class AppointmentForm(forms.ModelForm):
    scheduled_time = forms.DateTimeField(widget=forms.DateTimeInput(attrs={'type':'datetime-local','class':'form-control'}))
    class Meta:
        model = Appointment
        fields = ['patient','doctor','scheduled_time','reason','status']

class MedicalRecordForm(forms.ModelForm):
    class Meta:
        model = MedicalRecord
        fields = ['patient','appointment','summary','attachment']

class PrescriptionForm(forms.ModelForm):
    class Meta:
        model = Prescription
        fields = ['medical_record','medicine_text']
