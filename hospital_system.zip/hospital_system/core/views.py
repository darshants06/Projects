from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from django.utils import timezone
from .forms import UserLoginForm, UserRegisterForm, PatientForm, AppointmentForm, MedicalRecordForm, PrescriptionForm
from .models import Patient, Doctor, Appointment, MedicalRecord, Prescription, Invoice
from .utils import generate_invoice_pdf
from django.db.models import Count
from django.contrib.auth.models import Group

def is_doctor(user):
    return hasattr(user, 'doctor_profile')

def is_admin(user):
    return user.is_superuser

def is_reception(user):
    return user.groups.filter(name='Reception').exists()

def user_login(request):
    if request.user.is_authenticated:
        return redirect('core:dashboard')
    form = UserLoginForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        username = form.cleaned_data['username']
        password = form.cleaned_data['password']
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('core:dashboard')
        else:
            messages.error(request, 'Invalid credentials')
    return render(request, 'core/login.html', {'form': form})

def user_register(request):
    if request.user.is_authenticated:
        return redirect('core:dashboard')
    form = UserRegisterForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        user = form.save()
        # Optionally add to Reception group automatically:
        # try:
        #     group = Group.objects.get(name='Reception')
        #     user.groups.add(group)
        # except Group.DoesNotExist:
        #     pass
        messages.success(request, "Account created! You can now login.")
        return redirect('core:login')
    return render(request, 'core/register.html', {'form': form})

@login_required
def user_logout(request):
    logout(request)
    return redirect('core:login')

@login_required
def dashboard(request):
    if request.user.is_superuser:
        return dashboard_admin(request)
    if is_doctor(request.user):
        return dashboard_doctor(request)
    if is_reception(request.user):
        return dashboard_reception(request)
    return dashboard_admin(request)

@login_required
@user_passes_test(is_admin)
def dashboard_admin(request):
    stats = {
        'patients': Patient.objects.count(),
        'doctors': Doctor.objects.filter().count(),
        'appointments': Appointment.objects.filter(status='S').count(),
    }
    recent_appointments = Appointment.objects.order_by('-scheduled_time')[:10]
    return render(request, 'core/dashboard_admin.html', {'stats': stats, 'recent_appointments': recent_appointments})

@login_required
@user_passes_test(is_doctor)
def dashboard_doctor(request):
    doctor = request.user.doctor_profile
    today = timezone.now().date()
    todays_appts = doctor.appointments.filter(scheduled_time__date=today)
    return render(request, 'core/dashboard_doctor.html', {'doctor': doctor, 'todays_appts': todays_appts})

@login_required
@user_passes_test(is_reception)
def dashboard_reception(request):
    appointments = Appointment.objects.filter(status='S').order_by('scheduled_time')[:20]
    return render(request, 'core/dashboard_reception.html', {'appointments': appointments})

@login_required
def patients_list(request):
    q = request.GET.get('q')
    patients = Patient.objects.all().order_by('-created_at')
    if q:
        patients = (patients.filter(first_name__icontains=q) | patients.filter(last_name__icontains=q)).distinct()
    return render(request, 'core/patients_list.html', {'patients': patients})

@login_required
def patient_create(request):
    if request.method == 'POST':
        form = PatientForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, 'Patient created')
            return redirect('core:patients')
    else:
        form = PatientForm()
    return render(request, 'core/patient_create.html', {'form': form})

@login_required
def patient_detail(request, pk):
    patient = get_object_or_404(Patient, pk=pk)
    records = patient.medical_records.order_by('-created_at')
    invoices = patient.invoices.order_by('-issued_at')
    appointments = patient.appointments.order_by('-scheduled_time')
    return render(request, 'core/patient_detail.html', {'patient': patient, 'records': records, 'invoices': invoices, 'appointments': appointments})

@login_required
def doctors_list(request):
    doctors = Doctor.objects.select_related('user','department').all()
    return render(request, 'core/doctors_list.html', {'doctors': doctors})

@login_required
def doctor_detail(request, pk):
    doctor = get_object_or_404(Doctor, pk=pk)
    appts = doctor.appointments.order_by('-scheduled_time')
    return render(request, 'core/doctor_detail.html', {'doctor': doctor, 'appts': appts})

@login_required
def appointments_list(request):
    appts = Appointment.objects.select_related('patient','doctor').order_by('-scheduled_time')
    return render(request, 'core/appointments_list.html', {'appts': appts})

@login_required
def appointment_create(request):
    if request.method == 'POST':
        form = AppointmentForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Appointment scheduled')
            return redirect('core:appointments')
    else:
        form = AppointmentForm()
    return render(request, 'core/appointment_create.html', {'form': form})

@login_required
def appointment_cancel(request, pk):
    appt = get_object_or_404(Appointment, pk=pk)
    appt.status = 'C'
    appt.save()
    messages.success(request, 'Appointment cancelled')
    return redirect('core:appointments')

@login_required
def medical_record_create(request):
    if request.method == 'POST':
        form = MedicalRecordForm(request.POST, request.FILES)
        if form.is_valid():
            rec = form.save()
            messages.success(request, 'Medical record saved')
            return redirect('core:patient_detail', pk=rec.patient.pk)
    else:
        form = MedicalRecordForm()
    return render(request, 'core/medical_record_form.html', {'form': form})

@login_required
def prescriptions_list(request):
    pres = Prescription.objects.select_related('medical_record','medical_record__patient').order_by('-created_at')
    return render(request, 'core/prescriptions_list.html', {'prescriptions': pres})

@login_required
def prescription_create(request):
    if request.method == 'POST':
        form = PrescriptionForm(request.POST)
        if form.is_valid():
            pres = form.save()
            messages.success(request, 'Prescription created')
            return redirect('core:prescriptions')
    else:
        form = PrescriptionForm()
    return render(request, 'core/prescription_form.html', {'form': form})

@login_required
def invoice_create(request, appointment_pk=None, patient_pk=None):
    if request.method == 'POST':
        pid = request.POST.get('patient')
        amt = request.POST.get('amount') or 0
        patient = get_object_or_404(Patient, pk=pid)
        appt = None
        if appointment_pk:
            appt = get_object_or_404(Appointment, pk=appointment_pk)
        invoice = Invoice.objects.create(patient=patient, appointment=appt, amount=amt)
        generate_invoice_pdf(invoice)
        messages.success(request, 'Invoice created')
        return redirect('core:invoice_detail', pk=invoice.pk)
    patients = Patient.objects.all()
    return render(request, 'core/invoice_create.html', {'patients': patients, 'appointment_pk': appointment_pk})

@login_required
def invoice_detail(request, pk):
    invoice = get_object_or_404(Invoice, pk=pk)
    return render(request, 'core/invoice_detail.html', {'invoice': invoice})

@login_required
def reports(request):
    appts_per_doctor = Appointment.objects.values('doctor__user__username').annotate(total=Count('id')).order_by('-total')
    patients_count = Patient.objects.count()
    return render(request, 'core/reports.html', {'appts_per_doctor': appts_per_doctor, 'patients_count': patients_count})
