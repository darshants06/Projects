from django.urls import path
from . import views

app_name = 'core'

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('login/', views.user_login, name='login'),
    path('register/', views.user_register, name='register'),
    path('logout/', views.user_logout, name='logout'),

    path('patients/', views.patients_list, name='patients'),
    path('patients/new/', views.patient_create, name='patient_create'),
    path('patients/<int:pk>/', views.patient_detail, name='patient_detail'),

    path('doctors/', views.doctors_list, name='doctors'),
    path('doctors/<int:pk>/', views.doctor_detail, name='doctor_detail'),

    path('appointments/', views.appointments_list, name='appointments'),
    path('appointments/new/', views.appointment_create, name='appointment_create'),
    path('appointments/<int:pk>/cancel/', views.appointment_cancel, name='appointment_cancel'),

    path('records/new/', views.medical_record_create, name='medical_record_create'),
    path('prescriptions/', views.prescriptions_list, name='prescriptions'),
    path('prescriptions/new/', views.prescription_create, name='prescription_create'),

    path('invoices/new/', views.invoice_create, name='invoice_create'),
    path('invoices/<int:pk>/', views.invoice_detail, name='invoice_detail'),

    path('reports/', views.reports, name='reports'),
]
