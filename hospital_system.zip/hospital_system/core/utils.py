from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from django.conf import settings
import os

def generate_invoice_pdf(invoice):
    invoices_dir = os.path.join(settings.MEDIA_ROOT, 'invoices')
    os.makedirs(invoices_dir, exist_ok=True)

    filename = f"invoice_{invoice.pk}.pdf"
    fullpath = os.path.join(invoices_dir, filename)

    c = canvas.Canvas(fullpath, pagesize=A4)
    width, height = A4
    c.setFont('Helvetica-Bold', 18)
    c.drawString(50, height - 50, 'Hospital Invoice')
    c.setFont('Helvetica', 12)
    c.drawString(50, height - 90, f'Invoice No: {invoice.pk}')
    c.drawString(50, height - 110, f'Patient: {invoice.patient}')
    c.drawString(50, height - 130, f'Date: {invoice.issued_at.strftime("%Y-%m-%d %H:%M")}')
    c.drawString(50, height - 160, f'Amount: ₹{invoice.amount}')
    c.drawString(50, height - 180, f'Paid: {"Yes" if invoice.paid else "No"}')
    c.showPage()
    c.save()
    return os.path.join(settings.MEDIA_URL, 'invoices', filename)
